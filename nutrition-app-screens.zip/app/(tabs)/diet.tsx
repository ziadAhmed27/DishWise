import { useState } from 'react';
import { ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import Screen from '@/components/Screen';
import { colors, radius, spacing } from '@/constants/nutri';

type IconName = React.ComponentProps<typeof Ionicons>['name'];

const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

// TODO: fill meals with real plan data
const meals: { name: string; icon: IconName }[] = [
  { name: 'Breakfast', icon: 'sunny-outline' },
  { name: 'Lunch', icon: 'restaurant-outline' },
  { name: 'Dinner', icon: 'moon-outline' },
  { name: 'Snacks', icon: 'cafe-outline' },
];

const macros = ['Protein', 'Carbs', 'Fat'];

export default function DietScreen() {
  const [selected, setSelected] = useState(0);

  return (
    <Screen title="Diet plan" subtitle="Your meals for the day">
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.daysScroll}>
        {days.map((d, i) => (
          <TouchableOpacity
            key={d}
            onPress={() => setSelected(i)}
            style={[styles.day, selected === i && styles.dayActive]}
            activeOpacity={0.8}
          >
            <Text style={[styles.dayText, selected === i && styles.dayTextActive]}>{d}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <View style={styles.summary}>
        <Text style={styles.summaryLabel}>Daily calories</Text>
        <Text style={styles.summaryValue}>-- kcal</Text>
        <View style={styles.macroRow}>
          {macros.map((m) => (
            <View key={m} style={styles.macro}>
              <Text style={styles.macroValue}>--</Text>
              <Text style={styles.macroLabel}>{m}</Text>
            </View>
          ))}
        </View>
      </View>

      {meals.map((meal) => (
        <View key={meal.name} style={styles.meal}>
          <View style={styles.mealIcon}>
            <Ionicons name={meal.icon} size={20} color={colors.primary} />
          </View>
          <View style={styles.mealText}>
            <Text style={styles.mealName}>{meal.name}</Text>
            <Text style={styles.mealEmpty}>No meal added yet</Text>
          </View>
        </View>
      ))}
    </Screen>
  );
}

const styles = StyleSheet.create({
  daysScroll: { marginBottom: spacing.md, flexGrow: 0 },
  day: {
    paddingHorizontal: 18,
    paddingVertical: 10,
    borderRadius: radius.pill,
    backgroundColor: colors.card,
    borderWidth: 1,
    borderColor: colors.border,
    marginRight: spacing.sm,
  },
  dayActive: { backgroundColor: colors.primary, borderColor: colors.primary },
  dayText: { fontSize: 14, fontWeight: '600', color: colors.muted },
  dayTextActive: { color: '#fff' },
  summary: {
    backgroundColor: colors.primarySoft,
    borderRadius: radius.lg,
    padding: spacing.lg,
    marginBottom: spacing.md,
  },
  summaryLabel: { fontSize: 14, color: colors.muted },
  summaryValue: { fontSize: 30, fontWeight: '700', color: colors.primary, marginTop: 2 },
  macroRow: { flexDirection: 'row', marginTop: spacing.md, gap: spacing.sm },
  macro: {
    flex: 1,
    backgroundColor: colors.card,
    borderRadius: radius.md,
    paddingVertical: spacing.sm,
    alignItems: 'center',
  },
  macroValue: { fontSize: 16, fontWeight: '700', color: colors.text },
  macroLabel: { fontSize: 12, color: colors.muted, marginTop: 2 },
  meal: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.card,
    borderRadius: radius.md,
    padding: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
    marginBottom: spacing.sm,
  },
  mealIcon: {
    width: 42,
    height: 42,
    borderRadius: radius.sm,
    backgroundColor: colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: spacing.sm,
  },
  mealText: { flex: 1 },
  mealName: { fontSize: 16, fontWeight: '600', color: colors.text },
  mealEmpty: { fontSize: 13, color: colors.muted, marginTop: 2 },
});
