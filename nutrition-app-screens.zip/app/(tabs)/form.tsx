import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import Screen from '@/components/Screen';
import { colors, radius, spacing } from '@/constants/nutri';

// TODO: replace with real questions
const placeholderQuestions = [1, 2, 3, 4];
const TOTAL_STEPS = 5;
const CURRENT_STEP = 1;

export default function FormScreen() {
  return (
    <Screen title="About you" subtitle="Answer a few questions so we can personalize your plan.">
      <View style={styles.progressWrap}>
        <Text style={styles.progressText}>
          Step {CURRENT_STEP} of {TOTAL_STEPS}
        </Text>
        <View style={styles.track}>
          <View style={[styles.fill, { width: `${(CURRENT_STEP / TOTAL_STEPS) * 100}%` }]} />
        </View>
      </View>

      {placeholderQuestions.map((n) => (
        <View key={n} style={styles.question}>
          <Text style={styles.questionLabel}>Question {n}</Text>
          <View style={styles.inputPlaceholder}>
            <Text style={styles.inputHint}>Answer goes here</Text>
          </View>
        </View>
      ))}

      <TouchableOpacity style={styles.button} activeOpacity={0.85}>
        <Text style={styles.buttonText}>Continue</Text>
      </TouchableOpacity>
    </Screen>
  );
}

const styles = StyleSheet.create({
  progressWrap: { marginBottom: spacing.md },
  progressText: { fontSize: 13, color: colors.muted, marginBottom: 6 },
  track: { height: 8, borderRadius: radius.pill, backgroundColor: colors.border, overflow: 'hidden' },
  fill: { height: '100%', borderRadius: radius.pill, backgroundColor: colors.primary },
  question: {
    backgroundColor: colors.card,
    borderRadius: radius.md,
    padding: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
    marginBottom: spacing.sm,
  },
  questionLabel: { fontSize: 16, fontWeight: '600', color: colors.text, marginBottom: spacing.sm },
  inputPlaceholder: {
    height: 46,
    borderRadius: radius.sm,
    backgroundColor: colors.background,
    borderWidth: 1,
    borderColor: colors.border,
    justifyContent: 'center',
    paddingHorizontal: spacing.md,
  },
  inputHint: { color: colors.muted, fontSize: 14 },
  button: {
    backgroundColor: colors.primary,
    borderRadius: radius.pill,
    paddingVertical: 16,
    alignItems: 'center',
    marginTop: spacing.md,
  },
  buttonText: { color: '#fff', fontSize: 16, fontWeight: '700' },
});
