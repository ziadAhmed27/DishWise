import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import Screen from '@/components/Screen';
import { colors, radius, spacing } from '@/constants/nutri';

type IconName = React.ComponentProps<typeof Ionicons>['name'];

const stats = [
  { label: 'Weight', value: '--' },
  { label: 'Height', value: '--' },
  { label: 'Goal', value: '--' },
];

const menu: { label: string; icon: IconName }[] = [
  { label: 'Edit profile', icon: 'create-outline' },
  { label: 'Goals', icon: 'flag-outline' },
  { label: 'Notifications', icon: 'notifications-outline' },
  { label: 'Settings', icon: 'settings-outline' },
];

export default function ProfileScreen() {
  return (
    <Screen title="Profile">
      <View style={styles.userCard}>
        <View style={styles.avatar}>
          <Ionicons name="person" size={36} color={colors.primary} />
        </View>
        <Text style={styles.name}>Your name</Text>
        <Text style={styles.email}>you@email.com</Text>
      </View>

      <View style={styles.statsRow}>
        {stats.map((s) => (
          <View key={s.label} style={styles.stat}>
            <Text style={styles.statValue}>{s.value}</Text>
            <Text style={styles.statLabel}>{s.label}</Text>
          </View>
        ))}
      </View>

      <View style={styles.menu}>
        {menu.map((item, i) => (
          <TouchableOpacity
            key={item.label}
            style={[styles.row, i < menu.length - 1 && styles.rowDivider]}
            activeOpacity={0.6}
          >
            <View style={styles.rowIcon}>
              <Ionicons name={item.icon} size={20} color={colors.primary} />
            </View>
            <Text style={styles.rowLabel}>{item.label}</Text>
            <Ionicons name="chevron-forward" size={18} color={colors.muted} />
          </TouchableOpacity>
        ))}
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  userCard: {
    alignItems: 'center',
    backgroundColor: colors.card,
    borderRadius: radius.lg,
    padding: spacing.lg,
    borderWidth: 1,
    borderColor: colors.border,
  },
  avatar: {
    width: 84,
    height: 84,
    borderRadius: 42,
    backgroundColor: colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.sm,
  },
  name: { fontSize: 20, fontWeight: '700', color: colors.text },
  email: { fontSize: 14, color: colors.muted, marginTop: 2 },
  statsRow: { flexDirection: 'row', gap: spacing.sm, marginVertical: spacing.md },
  stat: {
    flex: 1,
    backgroundColor: colors.primarySoft,
    borderRadius: radius.md,
    paddingVertical: spacing.md,
    alignItems: 'center',
  },
  statValue: { fontSize: 18, fontWeight: '700', color: colors.primary },
  statLabel: { fontSize: 12, color: colors.muted, marginTop: 2 },
  menu: {
    backgroundColor: colors.card,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
  },
  row: { flexDirection: 'row', alignItems: 'center', padding: spacing.md },
  rowDivider: { borderBottomWidth: 1, borderBottomColor: colors.border },
  rowIcon: {
    width: 36,
    height: 36,
    borderRadius: radius.sm,
    backgroundColor: colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: spacing.sm,
  },
  rowLabel: { flex: 1, fontSize: 16, color: colors.text },
});
