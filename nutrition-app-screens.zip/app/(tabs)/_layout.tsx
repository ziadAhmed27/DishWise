import { Tabs } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '@/constants/nutri';

type IconName = React.ComponentProps<typeof Ionicons>['name'];

const tab = (title: string, active: IconName, inactive: IconName) => ({
  title,
  tabBarIcon: ({ focused, color, size }: { focused: boolean; color: string; size: number }) => (
    <Ionicons name={focused ? active : inactive} size={size} color={color} />
  ),
});

export default function TabLayout() {
  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.muted,
        tabBarStyle: {
          backgroundColor: colors.card,
          borderTopColor: colors.border,
        },
        tabBarLabelStyle: { fontSize: 12, fontWeight: '600' },
      }}
    >
      <Tabs.Screen name="index" options={tab('Profile', 'person', 'person-outline')} />
      <Tabs.Screen name="form" options={tab('My info', 'clipboard', 'clipboard-outline')} />
      <Tabs.Screen name="diet" options={tab('Diet plan', 'nutrition', 'nutrition-outline')} />
      <Tabs.Screen name="chat" options={tab('Assistant', 'chatbubble-ellipses', 'chatbubble-ellipses-outline')} />
    </Tabs>
  );
}
